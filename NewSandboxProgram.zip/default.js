// Arrow keys (or click a lane) to hit the arrows on the beat.
// SPACE or click = next screen, ENTER = skip to the game.

var WIDTH = getWidth();
var HEIGHT = getHeight();
var LANE_W = WIDTH / 4;
var HIT_Y = HEIGHT * 0.68;          // arrows hit
var BEAT = 16;                  

var ARROWS = ["←", "↓", "↑", "→"];
var COLORS = ["#ff3d9a", "#3de7ff", "#ffe45e", "#b58bff"];
var KEYS = [37, 40, 38, 39];        

// Difficulty
var TRAVEL = [0, 92, 80, 68, 56, 44];              
var SPAWN_CHANCE = [0, 0.4, 0.5, 0.45, 0.55, 0.7];   

var STORY = [
    ["🪩", "get your bounce back", "click for story", "ENTER = skip to the rave"],
    ["💔", "Scarlett thought Max was the one.", "Then his text came in:", "\"we need to talk.\""],
    ["😭", "A tear ran down until she realized how bad she was.", "Then she stood up and", "opened the closet."],
    ["👗", "Dress on. Hair done.", "Lashes on fleek.", "Scarlett is in her post breakup prime."],
    ["🎶", "The rave is loud and Max is", "somewhere in the crowd.", "Hit every arrow on the beat!"]
];


var state = "story";     
var page = 0;
var frame = 0;
var score = 0;
var combo = 0;
var bounce = 60;        
var level = 1;
var cleared = 0;         
var jellyTime = 0; 
var lastHit = -99; 
var feedbackTime = 0;
var notes = [];
var dancer = [];
var scoreText, levelText, feedbackText, barFill;

// we are dj's
var audioCtx = null;
var CHORDS = [[220, 262, 330], [175, 220, 262], [262, 330, 392], [196, 247, 294]];
var ROOTS = [110, 87, 131, 98];

function startAudio() {
    if (audioCtx === null) {
        try {
            audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        } catch (err) {
            audioCtx = null;
        }
    }
}

//catching a beat
function beep(freq, len, type, vol, endFreq) {
    if (audioCtx === null) {
        return;
    }
    var now = audioCtx.currentTime;
    var osc = audioCtx.createOscillator();
    var gain = audioCtx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    if (endFreq) {
        osc.frequency.exponentialRampToValueAtTime(endFreq, now + len);
    }
    gain.gain.setValueAtTime(vol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + len);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(now + len);
}

function playMusic() {
    if (frame % 4 !== 0) {
        return;                             
    }
    var step = frame / 4;
    var chord = Math.floor(step / 16) % 4;   // changes bar

    if (step % 4 === 0) {
        beep(150, 0.2, "sine", 0.8, 45);                
    }
    if (step % 4 === 2) {
        beep(ROOTS[chord], 0.2, "triangle", 0.4);        
        beep(8000, 0.04, "square", 0.03);           
    }
    if (step % 2 === 0) {
        beep(CHORDS[chord][(step / 2) % 3] * 2, 0.13, "sawtooth", 0.05);   
    }
    if (level >= 3 && step % 2 === 1) {
        beep(8000, 0.03, "square", 0.02);                // music change goes faster
    }
}

function drawBackground() {
    var bg = new Rectangle(WIDTH, HEIGHT);
    bg.setColor("#1b0a2f");
    add(bg);
}

function centerText(str, font, color, y) {
    var t = new Text(str, font);
    t.setColor(color);
    t.setPosition(WIDTH / 2 - t.getWidth() / 2, y);
    add(t);
}

function showPage() {
    removeAll();
    drawBackground();
    var p = STORY[page];
    centerText(p[0], "40pt Arial", "white", HEIGHT * 0.3);
    for (var i = 1; i < p.length; i++) {
        centerText(p[i], "14pt Arial", "white", HEIGHT * 0.42 + (i - 1) * 26);
    }
}

function nextScreen() {
    if (state === "story") {
        page++;
        if (page >= STORY.length) {
            startGame();
        } else {
            showPage();
        }
    } else if (state === "end") {
        startGame();
    }
}

function endGame(won) {
    state = "end";
    removeAll();
    drawBackground();
    if (won) {
        centerText("✨", "40pt Arial", "white", HEIGHT * 0.3);
        centerText("BOUNCE BACK COMPLETE!", "18pt Arial", "#ff3d9a", HEIGHT * 0.45);
    } else {
        centerText("💔", "40pt Arial", "white", HEIGHT * 0.3);
        centerText("HEARTBROKEN AGAIN", "18pt Arial", "#ff3d9a", HEIGHT * 0.45);
    }
    centerText("Score: " + score, "16pt Arial", "#ffe45e", HEIGHT * 0.6);
    centerText("Click or SPACE to play again", "12pt Arial", "#b58bff", HEIGHT * 0.8);
}

// ----- starting the game -----
function startGame() {
    state = "play";
    frame = 0;
    score = 0;
    combo = 0;
    bounce = 60;
    level = 1;
    cleared = 0;
    jellyTime = 0;
    lastHit = -99;
    notes = [];
    dancer = [];
    removeAll();
    drawBackground();

    for (var i = 0; i < 4; i++) {
        if (i % 2 === 0) {
            var lane = new Rectangle(LANE_W, HEIGHT);
            lane.setColor("#26103f");
            lane.setPosition(i * LANE_W, 0);
            add(lane);
        }
        var target = new Text(ARROWS[i], "30pt Arial");    // where to hit
        target.setColor("#6a4a8a");
        target.setPosition(i * LANE_W + LANE_W / 2 - target.getWidth() / 2, HIT_Y + 11);
        add(target);
    }

    var barBack = new Rectangle(WIDTH - 20, 12);
    barBack.setColor("#4a3560");
    barBack.setPosition(10, 36);
    add(barBack);
    barFill = new Rectangle(WIDTH - 20, 12);
    barFill.setColor("#ff3d9a");
    barFill.setPosition(10, 36);
    add(barFill);

    scoreText = new Text("", "13pt Arial");
    scoreText.setColor("white");
    scoreText.setPosition(10, 24);
    add(scoreText);
    levelText = new Text("", "13pt Arial");
    levelText.setColor("white");
    levelText.setPosition(WIDTH - 80, 24);
    add(levelText);
    feedbackText = new Text("", "16pt Arial");
    feedbackText.setPosition(10, 75);
    add(feedbackText);
}

function showFeedback(msg, color) {
    feedbackText.setText(msg);
    feedbackText.setColor(color);
    feedbackTime = 25;
}

//arrows
function spawnNote() {
    if (level > 5) {
        return;
    }
    var travel = TRAVEL[level];
    var every = BEAT;
    if (level >= 3) {
        every = BEAT / 2;      
    }
  
    if ((frame + travel) % every !== 0) {
        return;
    }
    if (Math.random() > SPAWN_CHANCE[level]) {
        return;
    }

    var n = {};
    n.lane = Randomizer.nextInt(0, 3);
    n.hit = frame + travel;            
    n.travel = travel;
    n.done = false;
    n.blob = null;

    var jellyChance = 0.06;
    if (bounce < 35) {
        jellyChance = 0.35;
    }
    n.jelly = Math.random() < jellyChance;
    if (n.jelly) {
        n.blob = new Circle(LANE_W * 0.4);
        n.blob.setColor("#ff7ac8");
        add(n.blob);
    }
    n.txt = new Text(ARROWS[n.lane], "30pt Arial");
    n.txt.setColor(n.jelly ? "white" : COLORS[n.lane]);
    add(n.txt);
    notes.push(n);
}

function goodWindow() {
    var w = 10 - level;
    if (jellyTime > 0) {
        w += 3; 
    }
    return w;
}

function updateNotes() {
    for (var i = notes.length - 1; i >= 0; i--) {
        var n = notes[i];
        var y = HIT_Y - (n.hit - frame) * (HIT_Y / n.travel);
        var cx = n.lane * LANE_W + LANE_W / 2;
        n.txt.setPosition(cx - n.txt.getWidth() / 2, y + 11);
        if (n.blob !== null) {
            n.blob.setPosition(cx, y);
        }

        if (!n.done && frame - n.hit > goodWindow() + 2) {   // missed it
            combo = 0;
            bounce -= 4 + level * 1.5;
            showFeedback("MISS", "#ff5a5a");
            noteFinished();
            n.done = true;
        }
        if (n.done) {
            remove(n.txt);
            if (n.blob !== null) {
                remove(n.blob);
            }
            notes.splice(i, 1);
        }
    }
}

function noteFinished() {
    cleared++;
    if (cleared >= 10 + level * 4) {
        level++;
        cleared = 0;
    }
}

// arrows miss/points earned
function pressLane(lane) {
    if (state !== "play" || lane < 0 || lane > 3) {
        return;
    }
    lastHit = frame;


    var best = null;
    var bestDiff = 999;
    for (var i = 0; i < notes.length; i++) {
        var n = notes[i];
        var diff = Math.abs(frame - n.hit);
        if (!n.done && n.lane === lane && diff <= goodWindow() && diff < bestDiff) {
            best = n;
            bestDiff = diff;
        }
    }

    if (best === null) {            
        bounce -= 1;
        combo = 0;
        showFeedback("oops", "#aaaaaa");
        return;
    }

    var perfect = (bestDiff <= 4);
    var points = perfect ? 100 : 60;
    if (jellyTime > 0) {
        points = points * 2;
    }
    score += points + combo * 5;
    combo++;
    bounce = Math.min(100, bounce + (perfect ? 4 : 2));
    showFeedback(perfect ? "PERFECT" : "good", perfect ? "#ffe45e" : "white");
    beep([880, 1046, 1318, 1568][lane], 0.15, "triangle", 0.2);

//add energy as level up
    if (best.jelly) {
        jellyTime = 280;                    
        bounce = Math.min(100, bounce + 25);    
        showFeedback("+ENERGY!", "#ff7ac8");
    }
    best.done = true;
    noteFinished();
}

// dancer

function addDot(x, y, radius, color) {
    var dot = new Circle(radius);
    dot.setColor(color);
    dot.setPosition(x, y);
    add(dot);
    dancer.push(dot);
}

function addLine(x1, y1, x2, y2, color, width) {
    var line = new Line(x1, y1, x2, y2);
    line.setColor(color);
    line.setLineWidth(width);
    add(line);
    dancer.push(line);
}


function drawLegs(x, feetY, s, sway) {
    var liftLeft = Math.max(0, sway) * 8 * s;     
    var liftRight = Math.max(0, -sway) * 8 * s;
    addLine(x, feetY - 34 * s, x - 14 * s, feetY - liftLeft, "#ffd3b8", 6 * s);
    addLine(x, feetY - 34 * s, x + 14 * s, feetY - liftRight, "#ffd3b8", 6 * s);
    addDot(x - 14 * s, feetY - liftLeft, 6 * s, "white");     
    addDot(x + 14 * s, feetY - liftRight, 6 * s, "white");
}

function drawDress(x, topY, feetY, s) {
    var dress = new Polygon();
    dress.addPoint(x - 9 * s, topY);
    dress.addPoint(x + 9 * s, topY);
    dress.addPoint(x + 26 * s, feetY - 28 * s);
    dress.addPoint(x - 26 * s, feetY - 28 * s);
    dress.setColor(jellyTime > 0 ? "#ffe45e" : "#ff3d9a");   
    add(dress);
    dancer.push(dress);

}

function drawArms(x, topY, s, sway) {
    var handY = topY + 10 * s + sway * 15 * s;    
    if (frame - lastHit < 12) {
        handY = topY - 40 * s;                   
    }
    addLine(x - 8 * s, topY + 4 * s, x - 34 * s, handY, "#ffd3b8", 5 * s);
    addLine(x + 8 * s, topY + 4 * s, x + 34 * s, handY, "#ffd3b8", 5 * s);
}

function drawHair(x, headY, s, sway) {
    addLine(x, headY, x - 22 * s - sway * 8 * s, headY + 20 * s, "#ff7ac8", 9 * s);   
    addDot(x, headY - 12 * s, 7 * s, "#ff7ac8");                                      
    addDot(x, headY - 2 * s, 16 * s, "#ff7ac8");                                      
}

function drawFace(x, headY, s) {
    addDot(x, headY, 14 * s, "#ffd3b8");                  
    addDot(x - 5 * s, headY - 1 * s, 2 * s, "#3b1d5a");  
    addDot(x + 5 * s, headY - 1 * s, 2 * s, "#3b1d5a");
    addDot(x, headY + 6 * s, 2.5 * s, "#c0392b");        
}

function drawDancer() {
    for (var i = 0; i < dancer.length; i++) {       
        remove(dancer[i]);
    }
    dancer = [];

    var s = HEIGHT / 480;                           
    var sway = Math.sin(frame * Math.PI / BEAT);
    var x = WIDTH / 2 + sway * 10 * s;
    var feetY = HEIGHT - 10;
    var headY = feetY - 110 * s - Math.abs(sway) * 8 * s;   
    var shoulderY = headY + 16 * s;

    drawHair(x, headY, s, sway);      
    drawLegs(x, feetY, s, sway);
    drawDress(x, shoulderY, feetY, s);
    drawArms(x, shoulderY, s, sway);
    drawFace(x, headY, s);
}

// game loop
function gameLoop() {
    if (state !== "play") {
        return;
    }
    frame++;
    playMusic();
    spawnNote();
    updateNotes();

    if (jellyTime > 0) {
        jellyTime--;
    }
    if (feedbackTime > 0) {
        feedbackTime--;
        if (feedbackTime === 0) {
            feedbackText.setText("");
        }
    }


    scoreText.setText("Score " + score + (combo > 1 ? "  x" + combo : ""));
    levelText.setText("Level " + Math.min(level, 5));
    barFill.setSize(Math.max(1, (WIDTH - 20) * Math.max(0, bounce) / 100), 12);
    barFill.setColor(bounce < 25 ? "#ff5a5a" : "#ff3d9a");
    drawDancer();

    if (bounce <= 0) {
        endGame(false);
    } else if (level > 5 && notes.length === 0) {
        endGame(true);
    }
}

// player input
function onKey(e) {
    startAudio();
    if (state === "play") {
        for (var i = 0; i < 4; i++) {
            if (e.keyCode === KEYS[i]) {
                pressLane(i);
            }
        }
    } else if (e.keyCode === 13) {
        startGame();
    } else if (e.keyCode === 32) {
        nextScreen();
    }
}

function onClick(e) {
    startAudio();
    if (state === "play") {
        pressLane(Math.floor(e.getX() / LANE_W));
    } else {
        nextScreen();
    }
}

function start() {
    showPage();
    keyDownMethod(onKey);
    mouseClickMethod(onClick);
    setTimer(gameLoop, 29);
}

start();